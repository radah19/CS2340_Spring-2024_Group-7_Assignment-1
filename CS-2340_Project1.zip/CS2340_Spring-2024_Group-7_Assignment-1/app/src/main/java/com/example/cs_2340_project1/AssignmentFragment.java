package com.example.cs_2340_project1;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicReferenceArray;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AssignmentFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AssignmentFragment extends Fragment implements Serializable {

    // Add button
    Button add_btn;

    // Creating ArrayList for bundle data
    ArrayList<AssignmentModel> assignmentBundle = new ArrayList<>();
    ArrayList<AssignmentModel> assignmentMon = new ArrayList<>();
    ArrayList<AssignmentModel> assignmentTues = new ArrayList<>();
    ArrayList<AssignmentModel> assignmentWed = new ArrayList<>();
    ArrayList<AssignmentModel> assignmentThur = new ArrayList<>();
    ArrayList<AssignmentModel> assignmentFri = new ArrayList<>();

    private RecyclerView recyclerViewMon;
    private RecyclerView recyclerViewTues;
    private RecyclerView recyclerViewWed;
    private RecyclerView recyclerViewThurs;

    private RecyclerView recyclerViewFri;

    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public AssignmentFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AssignmentFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AssignmentFragment newInstance(String param1, String param2) {
        AssignmentFragment fragment = new AssignmentFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle sentBundle = getArguments();
        if (sentBundle != null) {
            assignmentBundle = (ArrayList<AssignmentModel>) sentBundle.getSerializable("userAssignment");
            for (AssignmentModel i:assignmentBundle) {
                if (i.getRepeat().contains("Monday")) {
                    assignmentMon.add(i);
                } if (i.getRepeat().contains("Tuesday")) {
                    assignmentTues.add(i);
                } if (i.getRepeat().contains("Wednesday")) {
                    assignmentWed.add(i);
                } if (i.getRepeat().contains("Thursday")) {
                    assignmentThur.add(i);
                } if (i.getRepeat().contains("Friday")) {
                    assignmentFri.add(i);
                }// if
            } // for
        } // if

        // Grabbing sent over bundle

        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_assignment, container, false);
        // For the recycler view

        recyclerViewMon = view.findViewById(R.id.monday);
        RecycleViewAdapter adapter = new RecycleViewAdapter(assignmentMon, assignmentBundle);
        recyclerViewMon.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerViewMon.setAdapter(adapter);

        recyclerViewTues = view.findViewById(R.id.tuesday);
        RecycleViewAdapter adapterTues = new RecycleViewAdapter(assignmentTues, assignmentBundle);
        recyclerViewTues.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerViewTues.setAdapter(adapterTues);

        recyclerViewWed = view.findViewById(R.id.wednesday);
        RecycleViewAdapter adapterWed = new RecycleViewAdapter(assignmentWed, assignmentBundle);
        recyclerViewWed.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerViewWed.setAdapter(adapterWed);


        recyclerViewThurs = view.findViewById(R.id.thursday);
        RecycleViewAdapter adapterThurs = new RecycleViewAdapter(assignmentThur, assignmentBundle);
        recyclerViewThurs.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerViewThurs.setAdapter(adapterThurs);

        recyclerViewFri = view.findViewById(R.id.friday);
        RecycleViewAdapter adapterFri = new RecycleViewAdapter(assignmentFri, assignmentBundle);
        recyclerViewFri.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerViewFri.setAdapter(adapterFri);

        add_btn = view.findViewById(R.id.add_assignment);

        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddAssignment addFragment = new AddAssignment();
                Bundle bundle2 =  new Bundle();
                bundle2.putSerializable("send", assignmentBundle);
                addFragment.setArguments(bundle2);
                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.Maincontainer, addFragment).commit();


            }
        });
        return view;
    }
}