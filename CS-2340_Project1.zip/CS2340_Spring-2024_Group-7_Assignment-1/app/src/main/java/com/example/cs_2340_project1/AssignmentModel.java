package com.example.cs_2340_project1;

public class AssignmentModel {
    String location;
    String title;
    String courseName;
    String dateAndtime;
    String repeat;
    public AssignmentModel(String location, String title, String courseName, String dateAndtime, String repeat) {
        this.location = location;
        this.title = title;
        this.courseName = courseName;
        this.dateAndtime = dateAndtime;
        this.repeat = repeat;
    }

    public String getLocation() {
        return location;
    }

    public String getTitle() {
        return title;
    }

    public String getCourseName() {
        return courseName;
    }

    public String getDateAndtime() {
        return dateAndtime;
    }

    public String getRepeat() {
        return repeat;
    }



    public void setLocation(String location) {
        this.location = location;
    }

    public void setTitle(String professor) {
        this.title = title;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public void setDateAndtime(String dateAndtime) {
        this.dateAndtime = dateAndtime;
    }

    public void setRepeat(String repeat) {
        this.repeat = repeat;
    }
}
