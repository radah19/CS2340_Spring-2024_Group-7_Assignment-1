package com.example.cs_2340_project1;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecycleViewAdapterAssignment extends RecyclerView.Adapter<RecycleViewAdapterAssignment.MyViewHolder> {

    ArrayList<AssignmentModel> assignmentBundle;
    ArrayList<AssignmentModel> assignmentDay;

    public RecycleViewAdapterAssignment(ArrayList<AssignmentModel> assignmentDay, ArrayList<AssignmentModel> assignmentBundle) {
        this.assignmentBundle = assignmentBundle;
        this.assignmentDay = assignmentDay;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.one_line_assignment,parent,false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.className.setText(assignmentDay.get(position).getCourseName());
        holder.title.setText(assignmentDay.get(position).getTitle());
        holder.date.setText(assignmentDay.get(position).getDateAndtime());
        holder.repeat.setText(assignmentDay.get(position).getRepeat());
        holder.location.setText(assignmentDay.get(position).getLocation());
        holder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AddAssignment addAssignment = new AddAssignment();
                /*
                Bundle bundle = new Bundle();
                Toast.makeText(v.getContext(), String.valueOf(holder.getAbsoluteAdapterPosition()), Toast.LENGTH_SHORT).show();
                bundle.putSerializable("position", holder.getAbsoluteAdapterPosition());
                addClass.setArguments(bundle);
                 */
                Bundle bundle2 = new Bundle();
                bundle2.putSerializable("send", assignmentBundle);
                bundle2.putSerializable("position", holder.getAbsoluteAdapterPosition());
                addAssignment.setArguments(bundle2);
                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.Maincontainer, addAssignment).commit();
            }
        });
    }

    @Override
    public int getItemCount() {
        return assignmentDay.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView className;
        TextView title;
        TextView date;
        TextView repeat;
        TextView location;
        ConstraintLayout parentLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            className = itemView.findViewById(R.id.cl_class);
            title = itemView.findViewById(R.id.cl_section);
            date = itemView.findViewById(R.id.cl_date);
            repeat = itemView.findViewById(R.id.cl_repeat);
            location = itemView.findViewById(R.id.cl_location);
            parentLayout = itemView.findViewById(R.id.one_line_assignment);
        }
    } // MyViewHolder
}
